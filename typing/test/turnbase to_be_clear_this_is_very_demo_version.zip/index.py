import os, sys, time, random, json, keyboard
from hash_ import L, M
from gameData import randomize_map, maps

player = {
    "name": "",
    "x": 3,
    "y": 3,
    "level": 1,
    "xp": 0,
    "gold": 50,
    "health": 100,
    "inventory": [1],
    "maps": maps,
    "equipment": {"weapon": None, "armor": None, "shield": None},
}

def clean():
    if os.name == "nt": os.system("cls")
    else: os.system("clear")

def loading(message="Loading", symbols="|/-\\", delay=0.3, repeat=random.randint(1, 2), autoClear=True):
    maxs = 10
    filled = 0

    for i in range(repeat):
        for symbol in symbols:
            filled = (i + 1) * maxs // repeat
            bar = "◼" * filled + "◻" * (maxs - filled)

            print(f"\r {message} {symbol} {bar} \r", end="")
            time.sleep(delay + random.random() / 10)
    if autoClear: clean()

def saveToFile(player, show=False):
    save_file = "player.dbl"
    with open(save_file, "w") as file: file.write(L(player))
    if show: loading(message="[💾] Your data/action are being to save (DO NOT CLOSE PROGRAM)", repeat=random.randint(4, 5), delay=0.07, autoClear=False)

def generate_enemy():
    return {
        "name": "Goblin",
        "health": random.randint(3, 10),
        "attack": random.randint(2, 5),
        "gold": random.randint(1, 30),
        "xp": random.randint(5, 10),
    }

def display_map(player):
    clean()
    print("Player: {}  Health: {}  Gold: {}\n".format(player["name"], player["health"], player["gold"]))
    maps = player["maps"]
    for y in range(player["y"] - 4, player["y"] + 5):
        row = ""
        for x in range(player["x"] - 4, player["x"] + 5):
            if y == player["y"] and x == player["x"]: row += "0"
            elif y in maps and 0 <= x < len(maps[y][0]): row += maps[y][0][x]
            else: row += " "
        print(row)


def combat(player, enemy):
    print(f"An enemy {enemy['name']} appears!")
    while enemy["health"] > 0 and player["health"] > 0:
        input('[enter] to continue')
        clean()
        print(f"Enemy Health: {enemy['health']} | Your Health: {player['health']}")
        action = input("Choose an action\n1.attack\n2. item\n3. flee\n: ").strip().lower()
        saveToFile(player, False)
        print('\n')
        if action == "attack" or action == "1":
            damage = random.randint(3, 5)
            enemy["health"] -= damage
            print(f"You dealt {damage} damage!")
        elif action == "item" or action == "2":
            if 4 in player["inventory"]:
                heal = random.randint(5, 10)
                player["health"] += heal
                print(f"You used a health potion and healed {heal} health!")
                player["inventory"].remove(4)
                saveToFile(player, False)
            else: print("No health potions available!")
        elif action == "flee" or action == "3":
            if random.random() < 1 / 3:
                print("You successfully fled!")
                saveToFile(player, True)
                return
            else: print("Failed to flee!")
        else: print("Invalid action.")

        if enemy["health"] > 0:
            damage = random.randint(enemy["attack"] - 1, enemy["attack"] + 1)
            player["health"] -= damage
            print(f"The enemy attacks you for {damage} damage!")

    if player["health"] <= 0:
        print("You have been defeated...")
        exit()
    else: 
        print(f"You defeated the {enemy['name']}!")
        player["gold"] += enemy["gold"]
        player["xp"] += enemy["xp"]
        saveToFile(player, True)
        print("\n")

def move_player(direction, maps, player):
    dx, dy = 0, 0
    if direction == "w": dy = -1
    elif direction == "s": dy = 1
    elif direction == "a": dx = -1
    elif direction == "d": dx = 1

    new_x, new_y = player["x"] + dx, player["y"] + dy
    if 0 <= new_y < len(maps) and 0 <= new_x < len(maps[1][0]):
        if maps[new_y + 1][0][new_x] == "◻":
            player["x"], player["y"] = new_x, new_y
            if random.random() < 0.05: # 5%
                enemy = generate_enemy()
                combat(player, enemy)
        elif maps[new_y + 1][0][new_x] == "◼": print("[!] You cannot walk through walls!")
        saveToFile(player, False)

def game_loop(maps, player):
    while True:
        display_map(player)
        print("Use W/A/S/D to move. Press Q to quit.")
        key = keyboard.read_event(suppress=True).name

        if key in ["w", "a", "s", "d"]: move_player(key, maps, player)
        elif key == "q":
            ensure = input("Are you sure you want to quit? (y/n): ")
            if ensure.lower() == "y":
                saveToFile(player, True)
                exit("Goodbye!")
            break

def create_save(message=""):
    clean()
    print('Hey let create a new player save?\nso, What name for a new player')
    if message: print(f'Error Code: {message}')

    username = input(": ")

    if username.isspace() or username.startswith(' '): return create_save("username can't be empty.")
    elif username.strip() == "": return create_save("username can't be empty.")
    elif len(username) > 32: return create_save("username can't be longer than 32 characters.")
    
    player["maps"] = randomize_map(maps)
    player_data = {"name": username, "x": 0, "y": 0, "level": 0, "xp": 0, "gold": 50, "health": 100, "inventory_id": [1], "maps": maps,"equipment": {"weapon": None, "armor": None, "shield": None}}
    save_file = "player.dbl"
    with open(save_file, "w") as file: file.write(L(player_data))

    loading(message="[Creating] generating player.dbl save files", repeat=random.randint(4, 5), delay=0.09, autoClear=False)
    load_save()

def load_save():
    save_file = "player.dbl"
    if os.path.exists(save_file):
        with open(save_file, "r") as file: e = file.read()
        d = M(e)
        player = d
        return d
    else: print(f"No save file found at {save_file}.")

if __name__ == "__main__":
    clean()
    print("\rThis is loading screenie.\ntitle: turn base game\nmade by: @aitji\n")
    div = 1
    save_file = "player.dbl"
    
    if os.path.exists(save_file): load_save()
    else:
        loading(message="[Scaning] modules & paths", repeat=random.randint(4, 8) // div, delay=0.09 // div, autoClear=False)
        loading(message="[Scaning] for typing files", repeat=random.randint(2, 3) // div, delay=0.08 // div, autoClear=False)
        loading(message="[Scaning] for player file", repeat=random.randint(2, 3) // div, delay=0.15 // div, autoClear=True)

        create_save()

    loading(message="[Loading] Generating Terrain and monster", repeat=random.randint(4, 6), delay=0.03, autoClear=True)
    game_loop(player["maps"], player)