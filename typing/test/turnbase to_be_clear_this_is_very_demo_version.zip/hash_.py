import base64 as A,json as B,urllib.parse as C,codecs as E
def D(d):return E.encode(d,'rot_13')
def F(d):return A.b64encode(d.encode()).decode()
def G(e):return A.b64decode(e).decode()
def H(d):return C.quote(d)
def I(e):return C.unquote(e)
def J(d):return''.join(format(ord(A),'08b')for A in d)
def K(bd):return''.join(chr(int(bd[A:A+8],2))for A in range(0,len(bd),8))
def L(d):A=B.dumps(d);C=D(A);E=F(C);G=H(E);I=J(G);return I
def M(i):A=K(i);C=I(A);E=G(C);F=D(E);return B.loads(F)