import random

Id = {
    'Wooden Sword': {
        'id': 1,
        'shop': {'buy': 15, 'sell': 3},
        'equipment': {
            'type': 'attack',
            'attack': {'base': 3, 'max': 5},
            'defense': None,
            'armor': None,
            'heal': None,
        },
    },
    'Wooden Shield': {
        'id': 2,
        'shop': {'buy': 15, 'sell': 3},
        'equipment': {
            'type': 'defense',
            'attack': None,
            'defense': {'base': 3, 'max': 5},
            'armor': None,
            'heal': None,
        },
    },
    'Leather Armor': {
        'id': 3,
        'shop': {'buy': 15, 'sell': 3},
        'equipment': {
            'type': 'armor',
            'attack': None,
            'defense': None,
            'armor': {'base': 3, 'max': 5},
            'heal': None,
        },
    },
    'Health Potion': {
        'id': 4,
        'shop': {'buy': 8, 'sell': 2},
        'equipment': {
            'type': 'health',
            'attack': None,
            'defense': None,
            'armor': None,
            'heal': {'base': 5, 'max': 10},
        },
    },
}

maps = {
    15: ['◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼'],
    14: ['◼◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◼'],
    13: ['◼◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◼'],
    12: ['◼◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◼'],
    11: ['◼◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◼'],
    10: ['◼◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◼'],
    9 : ['◼◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◼'],
    8 : ['◼◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◼'],
    7 : ['◼◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◼'],
    6 : ['◼◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◼'],
    5 : ['◼◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◼'],
    4 : ['◼◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◼'],
    3 : ['◼◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◼'],
    2 : ['◼◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◼'],
    1 : ['◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼'],
}

def randomize_map(maps):
    map_height = len(maps)
    map_width = len(maps[1][0])
    mutable_map = {y: list(x[0]) for y, x in maps.items()}

    for y in range(1, map_height + 1):
        for x in range(map_width):
            if mutable_map[y][x] == '◻' and random.random() < 0.1: mutable_map[y][x] = '◼'

    maps = {y: [''.join(mutable_map[y])] for y in mutable_map}

    return maps